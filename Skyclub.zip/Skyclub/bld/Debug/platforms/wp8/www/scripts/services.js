﻿angular.module('application.services', [])

/**
 * A simple example service that returns some data.
 */

;


