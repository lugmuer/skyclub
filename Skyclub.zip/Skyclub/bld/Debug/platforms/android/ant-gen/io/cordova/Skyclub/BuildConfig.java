/** Automatically generated file. DO NOT MODIFY */
package io.cordova.Skyclub;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}